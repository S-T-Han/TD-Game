#ifndef BULLET_H
#define BULLET_H
#include"tdgobj.h"


class Bullet : public TDGObj
{
public:
    static map<string, Bullet> BULLET_SET;//确定各类子弹的属性
    static Bullet findBullet(string type);//根据名称找到子弹，读取对应的数据

    Bullet(){}
    Bullet(string type, int v, int damage);

    void move();//子弹向固定的方向移动
    void setDirection(int d){_direction=d;}//设定子弹的方向

    int getV() const {return this->_v;}
    int getStep() const {return this->_steps;}
    int getDamage() const {return this->_damage;}
    int getDirection() const{return _direction;}

private:
    string _type;//子弹的名称
    int _v, _damage, _steps, _direction;//子弹的速度、伤害、已经走过的步数、方向
};

#endif // BULLET_H
