#ifndef TDGOBJ_H
#define TDGOBJ_H
#include <QImage>
#include <QPainter>
#include <string>
#include <icon.h>
#include <map>
using namespace std;


class TDGObj
{
public:
    TDGObj(){}

    void initObj(string type);//根据名称载入一个游戏中的物体
    void show(QPainter* painter);//在窗体的特定位置绘制游戏中物体图标

    void setPosX(int x){this->_pos_x=x;}//设置物体的左上角横坐标
    void setPosY(int y){this->_pos_y=y;}//设置物体的左上角纵坐标

    int getPosX() const{return this->_pos_x;}
    int getPosY() const{return this->_pos_y;}
    int getHeight() const{return this->_icon.getHeight();}
    int getWidth() const{return this->_icon.getWidth();}

    string getObjType() const{return this->_icon.getTypeName();}//返回类名

protected:
    //所有坐标，单位均为游戏中的格

    QImage _pic;//游戏中物体所用的素材图片
    int _pos_x, _pos_y;//该物体在游戏中当前位置（左上角坐标）
    ICON _icon;//可以从ICON中获取对象的素材，尺寸等信息
};

#endif // TDGOBJ_H
