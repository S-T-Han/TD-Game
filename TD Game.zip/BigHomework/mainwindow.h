#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include<QKeyEvent>
#include<QTimer>
#include "tdgobj.h"
#include "world.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *e);
protected slots:
    void Move();
private slots:
    void on_pushButton_clicked();

private:
    QTimer *timer;
    Ui::MainWindow *ui;
    World _game;
    bool click;
    int _number;
};
#endif // MAINWINDOW_H
