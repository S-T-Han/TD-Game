#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "tdgobj.h"
#include "world.h"
#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include<QKeyEvent>
#include<QTimer>
#include<QMouseEvent>

#include<iostream>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *e);
    void mousePressEvent(QMouseEvent *event);

protected slots:
    void Move();
    void Add_Enemy();
    void Attack();
    void Judge();
    void Win();

private slots:
    void on_game1_clicked();
    void on_mechine_gun_clicked();
    void on_flame_gun_clicked();
    void on_remove_tower_clicked();
    void on_return_2_clicked();
    void on_push_to_start_clicked();
    void on_update_tower_clicked();
    void on_game2_clicked();
    void on_canon_clicked();

private:
    QTimer *move_timer, *enemies_timer, *attack_timer, *judge_timer, *end_timer;
    QString _enemyfile;
    QTextStream _in;
    Ui::MainWindow *ui;
    World _game;
    int _times, _x, _y;
    string _type_of_tower;
    bool _click_game;//用于检查pushbottom是否被按过
};
#endif // MAINWINDOW_H
