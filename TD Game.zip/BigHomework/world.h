#ifndef WORLD_H
#define WORLD_H
#include"tdgobj.h"
#include"enemy.h"
#include<vector>

class World
{
public:
    World(){this->_enemy=new Enemy;}

    void initWorld(string mapfile);
    void initEnemy(string enemyfile);
    void show(QPainter* painter);

    void eraseObj(int x, int y);
    void handle_Enemy_move(string type);

    vector<Enemy*> *_enemies;
private:
    vector<TDGObj*> _objs;
    Enemy *_enemy;

};

#endif // WORLD_H
