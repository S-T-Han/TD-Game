#ifndef WORLD_H
#define WORLD_H
#include"tdgobj.h"
#include"enemy.h"
#include"tower.h"
#include"bullet.h"
#include<QMediaPlayer>
#include<vector>
#include<QIODevice>
#include<QFile>
#include<QString>
#include<QStringList>
#include<QTextStream>
#include<QDebug>
#include<QMediaPlayer>

class World
{
public:
    World(){_score=10, _live=3;}
    ~World(){vector<TDGObj*>().swap(_road); vector<TDGObj*>().swap(_lives); vector<Enemy*>().swap(_enemies); vector<Tower*>().swap(_towers);}//回收内存空间

    void initRoad(const QString& mapfile);//载入地图
    bool have_Road(int x, int y);//判断某个位置是否有道路
    void cleanWorld();//清除当前世界

    void handle_Enemy_add(string type);//增加某个类型的敌人
    void handle_Enemy_move();//所有敌人移动一次
    bool have_Enemy(int x, int y);//判断某个位置是否有敌人
    void eraser_Enemy(int x, int y);//销毁某个位置的敌人

    void handle_tower_add(string type, int x, int y);//在某个位置增加哦某个类型的防御塔
    void handle_tower_update(string type, int x, int y);//在某个位置升级某个类型的防御塔
    void handle_tower_attack();//所有防御塔攻击一次（包括计数器变化但不射出子弹）
    void erase_Tower(int x, int y);//销毁某个位置的防御塔
    bool can_build(int x, int y);//判断某个位置是否能修建防御塔
    string have_tower(int x, int y);//判断某个位置是否有防御塔，并返回它的名称（没有则返回none）

    void hit_judge();//子弹与敌人的碰撞判断
    void cross_judge();//敌人到达终点的判断

    int getScore() const{return _score;}
    void changeScore(int a){_score+=a;}
    int getLive() const{return _live;}

    void show(QPainter* painter);//绘制游戏中的物体

private:
    vector<TDGObj*> _road;//游戏的道路
    vector<TDGObj*> _lives;//游戏的生命值标识
    vector<Enemy*> _enemies;//游戏的敌人
    vector<Tower*> _towers;//游戏的防御塔

    int _score, _live;//游戏的分数、生命值

    QMediaPlayer* _player;//音频播放器
};

#endif // WORLD_H
