#include "meun1.h"
#include "ui_meun1.h"

meun1::meun1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::meun1)
{
    ui->setupUi(this);
}

meun1::~meun1()
{
    delete ui;
}
