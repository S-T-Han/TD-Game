/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGroupBox *main_menu;
    QPushButton *game1;
    QPushButton *game2;
    QSpinBox *score_shower;
    QGroupBox *towers_list;
    QPushButton *flame_gun;
    QPushButton *mechine_gun;
    QPushButton *canon;
    QGroupBox *Tool_list;
    QPushButton *remove_tower;
    QPushButton *update_tower;
    QPushButton *useless_botton;
    QPushButton *return_2;
    QPushButton *push_to_start;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        main_menu = new QGroupBox(centralwidget);
        main_menu->setObjectName(QString::fromUtf8("main_menu"));
        main_menu->setGeometry(QRect(190, 70, 391, 331));
        main_menu->setAlignment(Qt::AlignCenter);
        game1 = new QPushButton(main_menu);
        game1->setObjectName(QString::fromUtf8("game1"));
        game1->setGeometry(QRect(50, 60, 281, 51));
        game2 = new QPushButton(main_menu);
        game2->setObjectName(QString::fromUtf8("game2"));
        game2->setGeometry(QRect(50, 160, 281, 51));
        score_shower = new QSpinBox(centralwidget);
        score_shower->setObjectName(QString::fromUtf8("score_shower"));
        score_shower->setGeometry(QRect(670, 480, 45, 24));
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(9);
        score_shower->setFont(font);
        towers_list = new QGroupBox(centralwidget);
        towers_list->setObjectName(QString::fromUtf8("towers_list"));
        towers_list->setGeometry(QRect(40, 410, 141, 131));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(6);
        towers_list->setFont(font1);
        flame_gun = new QPushButton(towers_list);
        flame_gun->setObjectName(QString::fromUtf8("flame_gun"));
        flame_gun->setGeometry(QRect(10, 60, 121, 21));
        flame_gun->setFont(font1);
        mechine_gun = new QPushButton(towers_list);
        mechine_gun->setObjectName(QString::fromUtf8("mechine_gun"));
        mechine_gun->setGeometry(QRect(10, 30, 121, 21));
        mechine_gun->setFont(font1);
        canon = new QPushButton(towers_list);
        canon->setObjectName(QString::fromUtf8("canon"));
        canon->setGeometry(QRect(10, 90, 121, 21));
        Tool_list = new QGroupBox(centralwidget);
        Tool_list->setObjectName(QString::fromUtf8("Tool_list"));
        Tool_list->setGeometry(QRect(200, 410, 131, 91));
        Tool_list->setFont(font1);
        remove_tower = new QPushButton(Tool_list);
        remove_tower->setObjectName(QString::fromUtf8("remove_tower"));
        remove_tower->setGeometry(QRect(10, 30, 111, 23));
        update_tower = new QPushButton(Tool_list);
        update_tower->setObjectName(QString::fromUtf8("update_tower"));
        update_tower->setGeometry(QRect(10, 60, 111, 23));
        useless_botton = new QPushButton(centralwidget);
        useless_botton->setObjectName(QString::fromUtf8("useless_botton"));
        useless_botton->setEnabled(false);
        useless_botton->setGeometry(QRect(630, 330, 80, 17));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Arial"));
        font2.setPointSize(6);
        font2.setBold(true);
        font2.setItalic(true);
        font2.setWeight(75);
        useless_botton->setFont(font2);
        useless_botton->setFlat(false);
        return_2 = new QPushButton(centralwidget);
        return_2->setObjectName(QString::fromUtf8("return_2"));
        return_2->setGeometry(QRect(10, 10, 141, 31));
        push_to_start = new QPushButton(centralwidget);
        push_to_start->setObjectName(QString::fromUtf8("push_to_start"));
        push_to_start->setGeometry(QRect(260, 500, 261, 41));
        push_to_start->setFlat(true);
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 360, 731, 141));
        QFont font3;
        font3.setFamily(QString::fromUtf8("Arial"));
        font3.setPointSize(36);
        label->setFont(font3);
        label->setAlignment(Qt::AlignCenter);
        MainWindow->setCentralWidget(centralwidget);
        label->raise();
        main_menu->raise();
        score_shower->raise();
        towers_list->raise();
        Tool_list->raise();
        useless_botton->raise();
        return_2->raise();
        push_to_start->raise();
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);
        QObject::connect(game1, SIGNAL(clicked()), main_menu, SLOT(hide()));
        QObject::connect(game1, SIGNAL(clicked()), score_shower, SLOT(show()));
        QObject::connect(return_2, SIGNAL(clicked()), towers_list, SLOT(hide()));
        QObject::connect(return_2, SIGNAL(clicked()), Tool_list, SLOT(hide()));
        QObject::connect(return_2, SIGNAL(clicked()), score_shower, SLOT(hide()));
        QObject::connect(push_to_start, SIGNAL(clicked()), main_menu, SLOT(show()));
        QObject::connect(return_2, SIGNAL(clicked()), push_to_start, SLOT(show()));
        QObject::connect(push_to_start, SIGNAL(clicked()), push_to_start, SLOT(hide()));
        QObject::connect(return_2, SIGNAL(clicked()), return_2, SLOT(hide()));
        QObject::connect(game2, SIGNAL(clicked()), main_menu, SLOT(hide()));
        QObject::connect(game2, SIGNAL(clicked()), score_shower, SLOT(show()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        main_menu->setTitle(QApplication::translate("MainWindow", "main_menu", nullptr));
        game1->setText(QApplication::translate("MainWindow", "game 1", nullptr));
        game2->setText(QApplication::translate("MainWindow", "game 2", nullptr));
        towers_list->setTitle(QApplication::translate("MainWindow", "Towers_list", nullptr));
        flame_gun->setText(QApplication::translate("MainWindow", "flame_gun", nullptr));
        mechine_gun->setText(QApplication::translate("MainWindow", "mechine_gun", nullptr));
        canon->setText(QApplication::translate("MainWindow", "canon", nullptr));
        Tool_list->setTitle(QApplication::translate("MainWindow", "Tool_list", nullptr));
        remove_tower->setText(QApplication::translate("MainWindow", "remove_tower", nullptr));
        update_tower->setText(QApplication::translate("MainWindow", "update_tower", nullptr));
        useless_botton->setText(QApplication::translate("MainWindow", "?", nullptr));
        return_2->setText(QApplication::translate("MainWindow", "Return", nullptr));
        push_to_start->setText(QApplication::translate("MainWindow", "push_to_start", nullptr));
        label->setText(QApplication::translate("MainWindow", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
