#include "enemy.h"
#include<iostream>

pair<string, Enemy> PairArray_Enemy[]=
{
    make_pair("fieldstick", Enemy("fieldstick", 1, 3)),
    make_pair("empty", Enemy("empty", 0, -1)),
    make_pair("bug", Enemy("bug", 3, 1)),
    make_pair("overload", Enemy("overload", 1, 25))
};

map<string, Enemy> Enemy::ENEMY_SET(PairArray_Enemy,PairArray_Enemy+sizeof(PairArray_Enemy)/sizeof(PairArray_Enemy[0]));

Enemy::Enemy(string type, int v, int blood):_type(type), _v(v), _blood(blood), _steps(0){}

Enemy Enemy::findenemy(string type){
    map<string, Enemy>::iterator kv;
    kv=Enemy::ENEMY_SET.find(type);

    if(kv==Enemy::ENEMY_SET.end()){
        cout<<"Error: cannot find enemy"<<endl;
        return Enemy();
    }
    else{
        return kv->second;
    }
}

//敌人可以变向，方向为上/下/左/右
void Enemy::move(int direction){
    switch (direction) {
    case 1:
        _pos_x++;
        break;
    case 2:
        _pos_y--;
        break;
    case 3:
        _pos_x--;
        break;
    case 4:
        _pos_y++;
        break;
    }
    _steps++;
}

