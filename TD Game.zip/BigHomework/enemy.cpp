#include "enemy.h"
#include<iostream>

pair<string, Enemy> PairArray[]=
{
    make_pair("fieldstick", Enemy("fieldstick", 1, 3))
};

map<string, Enemy> Enemy::ENEMY_SET(PairArray,PairArray+sizeof(PairArray)/sizeof(PairArray[0]));

Enemy::Enemy(string type, int v, int blood):_type(type), _v(v), _blood(blood){}

Enemy Enemy::findenemy(string type){
    map<string, Enemy>::iterator kv;
    kv=Enemy::ENEMY_SET.find(type);

    if(kv==Enemy::ENEMY_SET.end()){
        cout<<"Error: cannot find enemy"<<endl;
        return Enemy();
    }
    else{
        return kv->second;
    }
}


