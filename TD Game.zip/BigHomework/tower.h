#ifndef TOWER_H
#define TOWER_H
#include"tdgobj.h"
#include"bullet.h"
#include <string>
#include<vector>
#include<map>

class Tower : public TDGObj
{
public:
    static map<string, Tower> TOWER_SET;//确定各类防御塔的属性
    static Tower findtower(string type);//根据名称找到子弹，读取对应的数据

    Tower(){}
    Tower(string tower_type, string bullet_type, int interval, int area, int cost);
    ~Tower(){vector<Bullet*>().swap(_bullets);}//回收内存空间

    void changeCount();//改变防御塔计数器的值
    void attack(int direction);//防御塔向某个方向发射子弹

    string getTowerType() const{return  _tower_type;}
    string getBulletType() const {return _bullet_type;}
    int getCount() const {return _count;}
    int getInterval() const {return _interval;}
    int getArea() const {return _area;}
    static int getCost(string type);

    //为World类提供操作_bullets的方法
    void erase_Bullet(int x, int y);
    void erase_Bullet(vector<Bullet*>::iterator it){it=_bullets.erase(it);}
    int getBulletsize() const{return _bullets.size();}
    Bullet* getBullet(int i) const{return _bullets.at(i);}
    vector<Bullet*>::iterator getBulletstart(){return _bullets.begin();}
    vector<Bullet*>::iterator getBulletend(){return _bullets.end();}

private:
    string _tower_type, _bullet_type;//防御塔的名称、子弹的名称
    int _interval, _area, _cost, _count;//防御塔的发射间隔、范围、费用、计数器
    vector<Bullet*> _bullets;//防御塔的子弹
    //计数器的作用是记录防御塔据发射上一颗子弹过的时间
};

#endif // TOWER_H
