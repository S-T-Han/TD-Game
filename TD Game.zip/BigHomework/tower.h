#ifndef TOWER_H
#define TOWER_H
#include"tdgobj.h"


class Tower : public TDGObj
{
public:
    Tower();
};

#endif // TOWER_H
