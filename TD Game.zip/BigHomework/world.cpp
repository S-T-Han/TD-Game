#include "world.h"
#include<iostream>

using namespace std;

void World::initRoad(const QString& mapfile){
    QFile file(mapfile);
    QTextStream in(&file);
    QString line;
    QStringList list;

    if(file.open(QIODevice::ReadOnly | QIODevice::Text)) // 有该文件
    {
        while (!in.atEnd()) {
           line=in.readLine();
           list=line.split(",");

           _road.push_back(new TDGObj);
           _road.back()->initObj("road");
           _road.back()->setPosX(list.at(0).toInt());
           _road.back()->setPosY(list.at(1).toInt());
        }
    }
    else // 没有该文件
    {
        cout <<"no such file" << endl;
    }

    for(int i=0; i<3; i++){
        _lives.push_back(new TDGObj);
        _lives[i]->initObj("heart");
        _lives[i]->setPosX(22+i);
        _lives[i]->setPosY(0);
    }

    _player = new QMediaPlayer;
    _player->setMedia(QUrl("qrc:/hdl.mp3"));
    _player->setVolume(30);
    _player->play();
}

bool World::have_Road(int x, int y){
    vector<TDGObj*>::iterator it;
    it=_road.begin();

    while (it!=_road.end()) {
        int flag1=((*it)->getPosX()==x && (*it)->getPosY()==y);

        if(flag1){
            return true;
        }
        else{
            it++;
        }
    }

    return false;
}

void World::cleanWorld(){
    vector<TDGObj*>().swap(_road);
    vector<TDGObj*>().swap(_lives);
    vector<Enemy*>().swap(_enemies);
    vector<Tower*>().swap(_towers);

    _score=10;
    _live=3;

    delete _player;
}


void World::handle_Enemy_add(string type){
    int n=_enemies.size();
    _enemies.push_back(new Enemy);

    //在道路起点的位置增加一名敌人
    *_enemies[n]=Enemy::findenemy(type);
    _enemies[n]->initObj(type);
    _enemies[n]->setPosX(_road[0]->getPosX());
    _enemies[n]->setPosY(_road[0]->getPosY());
}

void World::handle_Enemy_move(){
    int n=_enemies.size();

    //每个敌人检索下一格道路的位置，并移动过去
    for(int i=0; i<n; i++){
        for(int j=0; j<_enemies[i]->getV(); j++){
            if(_road[_enemies[i]->getSteps()+1]->getPosX()==_enemies[i]->getPosX()+1 && _road[_enemies[i]->getSteps()+1]->getPosY()==_enemies[i]->getPosY()){
                _enemies[i]->move(1);
                continue;
            }
            if(_road[_enemies[i]->getSteps()+1]->getPosX()==_enemies[i]->getPosX() && _road[_enemies[i]->getSteps()+1]->getPosY()==_enemies[i]->getPosY()-1){
                _enemies[i]->move(2);
                continue;
            }
            if(_road[_enemies[i]->getSteps()+1]->getPosX()==_enemies[i]->getPosX() && _road[_enemies[i]->getSteps()+1]->getPosY()==_enemies[i]->getPosY()+1){
                _enemies[i]->move(4);
                continue;
            }
            if(_road[_enemies[i]->getSteps()+1]->getPosX()==_enemies[i]->getPosX()-1 && _road[_enemies[i]->getSteps()+1]->getPosY()==_enemies[i]->getPosY()){
                _enemies[i]->move(3);
                continue;
            }
        }
    }

}

void World::eraser_Enemy(int x, int y){
    vector<Enemy*>::iterator it;

    it=_enemies.begin();
    while (it!=_enemies.end()) {
        int flag1=((*it)->getPosX()==x && (*it)->getPosY()==y);

        if(flag1){
            delete (*it);
            it=_enemies.erase(it);
            break;
        }
        else{
            it++;
        }
    }
}

bool World::have_Enemy(int x, int y){
    vector<Enemy*>::iterator it;

    it=_enemies.begin();
    while (it!=_enemies.end()) {
        int flag1=((*it)->getPosX()==x && (*it)->getPosY()==y);

        if(flag1){
            return true;
        }
        else{
            it++;
        }
    }

    return false;
}

void World::handle_tower_add(string type, int x, int y){
    if(_score<Tower::getCost(type)){
        cout<<"no enough score"<<endl;
    }
    else{
        int n=_towers.size();
        _towers.push_back(new Tower);

        *_towers[n]=Tower::findtower(type);
        _towers[n]->initObj(type);
        _towers[n]->setPosX(x);
        _towers[n]->setPosY(y);

        _score-=Tower::getCost(type);

        QMediaPlayer* player = new QMediaPlayer;
        player->setMedia(QUrl("qrc:/2953.mp3"));
        player->setVolume(30);
        player->play();
    }
}

void World::handle_tower_update(string type, int x, int y){
    string s="update_"+type;
    if(_score<Tower::getCost(s)){
        cout<<"no enough score"<<endl;
    }
    else{
        erase_Tower(x, y);
        handle_tower_add(s, x, y);
    }
}

void World::handle_tower_attack(){
    int n=_towers.size();

    for(int i=0; i<n; i++){
        int area=_towers[i]->getArea();
        int x=_towers[i]->getPosX();
        int y=_towers[i]->getPosY();
        int flag=0;

        //在该方向检索到即将到来的敌人或远去的敌人，则向该方向发射子弹
        for(int j=1; j<area; j++){
            for(int k=-(j-1); k<j; k++){
                if(have_Enemy(x+j, y+k) && have_Road(x+j, y)){
                    flag=1;
                    break;
                }
                if(have_Enemy(x+k, y-j) && have_Road(x, y-j)){
                    flag=2;
                    break;
                }
                if(have_Enemy(x+k, y+j) && have_Road(x, y+j)){
                    flag=4;
                    break;
                }
                if(have_Enemy(x-j, y+k) && have_Road(x-j, y)){
                    flag=3;
                    break;
                }
            }
        }

        _towers[i]->attack(flag);
    }

}

void World::erase_Tower(int x, int y){
    vector<Tower*>::iterator it;

    it=_towers.begin();
    while (it!=_towers.end()) {
        int flag1=((*it)->getPosX()==x && (*it)->getPosY()==y);

        if(flag1){
            delete (*it);
            it=_towers.erase(it);
            break;
        }
        else{
            it++;
        }
    }
}

bool World::can_build(int x, int y){
    vector<TDGObj*>::iterator it;
    vector<Tower*>::iterator It;

    it=_road.begin();
    while (it!=_road.end()) {
        int flag1=((*it)->getPosX()==x && (*it)->getPosY()==y);

        if(flag1){
            return false;
        }
        else{
            it++;
        }
    }

    It=_towers.begin();
    while (It!=_towers.end()) {
        int flag1=((*It)->getPosX()==x && (*It)->getPosY()==y);

        if(flag1){
            return false;
        }
        else{
            It++;
        }
    }

    return true;
}

string World::have_tower(int x, int y){
    vector<Tower*>::iterator It;

    It=_towers.begin();
    while (It!=_towers.end()) {
        int flag1=((*It)->getPosX()==x && (*It)->getPosY()==y);

        if(flag1){
            return (*It)->getTowerType();
        }
        else{
            It++;
        }
    }

    return "none";
}

void World::hit_judge(){
    int n=_enemies.size();
    int m=_towers.size();
    vector<Bullet*>::iterator it;

    for(int i=0; i<n; i++){
        int x=_enemies[i]->getPosX();
        int y=_enemies[i]->getPosY();

        if(_enemies[i]->getBlood()<0){
            eraser_Enemy(x, y);
            continue;
        }

        for(int j=0; j<m; j++){
            it=_towers[j]->getBulletstart();

            while (it!=_towers[j]->getBulletend()) {
                int flag1=((*it)->getPosX()==x && (*it)->getPosY()==y);

                if(flag1){
                    if(_enemies[i]->getBlood()>(*it)->getDamage()){
                        _enemies[i]->get_hit( (*it)->getDamage() );
                    }
                    else{
                        eraser_Enemy(x, y);
                        _score++;

                        QMediaPlayer * player = new QMediaPlayer;
                        player->setMedia(QUrl("qrc:/crash.mp3"));
                        player->setVolume(30);
                        player->play();
                    }

                    delete (*it);
                    _towers[j]->erase_Bullet(it);

                    break;
                }
                else{
                    it++;
                }
            }

        }

    }
}

void World::cross_judge(){
    int n=_enemies.size();
    int m=_road.size()-5;
    for(int i=0; i<n; i++){
        if(_enemies[i]->getSteps()>=m){
            eraser_Enemy(_enemies[i]->getPosX(), _enemies[i]->getPosY());

            if(_live>0){
                vector<TDGObj*>::iterator it;

                it=_lives.begin();
                delete (*it);
                it=_lives.erase(it);

                _live--;
            }

            cout<<"Death is coming closer!"<<endl;
        }
    }
}


void World::show(QPainter * painter){
    int n=_road.size();
    for (int i=0;i<n;i++){
        this->_road[i]->show(painter);
    }

    n=_lives.size();
    for (int i=0;i<n;i++){
        this->_lives[i]->show(painter);
    }

    n=_enemies.size();
    for(int i=0; i<n; i++){
        _enemies[i]->show(painter);
    }

    n=_towers.size();
    for(int i=0; i<n; i++){
        _towers[i]->show(painter);
        int m=_towers[i]->getBulletsize();
        for(int j=0; j<m; j++){
            _towers[i]->getBullet(j)->show(painter);
        }
    }

}
