#include "world.h"
#include<iostream>

using namespace std;

void World::initWorld(string mapfile){
    vector<TDGObj*> q;
    for(int i=0; i<30; i++){
        q.push_back(new TDGObj);
        q[i]->initObj("road");
        q[i]->setPosX(i);
        q[i]->setPosY(6);
        this->_objs.push_back(q[i]);
    }
}

void World::initEnemy(string enemyfile){
    this->_enemy->initObj(enemyfile);
    this->_enemy->setPosX(1);
    this->_enemy->setPosY(5);

}

void World::show(QPainter * painter){
    int n = this->_objs.size();
    for (int i=0;i<n;i++){
        this->_objs[i]->show(painter);
    }
    this->_enemy->show(painter);
}

void World::eraseObj(int x, int y){
    vector<TDGObj*>::iterator it;
    it = _objs.begin();
    while(it!=_objs.end()){
        int flag1 = ((*it)->getObjType()!="stone" && (*it)->getObjType()!="road"); //不是石头
        int flag2 = ((*it)->getPosX() == x) && ((*it)->getPosY()==y);//位置重叠

        if (flag1 && flag2){
            cout<<(*it)->getObjType()<<endl;
            delete (*it);
            it = this->_objs.erase(it);
            break;
         }
        else{
            it++;
        }
    }
}

void World::handle_Enemy_move(string type){
    this->_enemy->move();
}
