#ifndef MEUN1_H
#define MEUN1_H

#include <QDialog>

namespace Ui {
class meun1;
}

class meun1 : public QDialog
{
    Q_OBJECT

public:
    explicit meun1(QWidget *parent = nullptr);
    ~meun1();

private:
    Ui::meun1 *ui;
};

#endif // MEUN1_H
