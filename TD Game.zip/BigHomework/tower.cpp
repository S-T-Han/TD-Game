#include "tower.h"

Tower::Tower()
{

}
