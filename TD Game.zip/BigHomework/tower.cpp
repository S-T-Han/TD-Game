#include "tower.h"
#include<iostream>

pair<string, Tower> PairArray_Tower[]=
{
    make_pair("mechine_gun", Tower("mechine_gun", "mechine_gun_bullet", 5, 10, 5)),
    make_pair("flame_gun", Tower("flame_gun", "flame_gun_bullet", 0, 3, 5)),
    make_pair("update_mechine_gun", Tower("update_mechine_gun", "mechine_gun_bullet", 4, 10, 3)),
    make_pair("update_flame_gun", Tower("update_flame_gun", "flame_gun_bullet", 0, 5, 5)),
    make_pair("canon", Tower("canon", "canon_bullet", 10, 10, 5)),
    make_pair("update_canon", Tower("update_canon", "update_canon_bullet", 10, 10, 5))
};

map<string, Tower> Tower::TOWER_SET(PairArray_Tower,PairArray_Tower+sizeof(PairArray_Tower)/sizeof(PairArray_Tower[0]));

Tower::Tower(string tower_type, string bullet_type, int interval, int area, int cost):
    _tower_type(tower_type),_bullet_type(bullet_type), _interval(interval), _area(area), _cost(cost),_count(0) {}

Tower Tower::findtower(string type){
    map<string, Tower>::iterator kv;
    kv=Tower::TOWER_SET.find(type);

    if(kv==Tower::TOWER_SET.end()){
        cout<<"Error: cannot find enemy"<<endl;
        return Tower();
    }
    else{
        return kv->second;
    }
}

//当计数器的值达到间隔，可以发射下一枚子弹，同时重置计数器
void Tower::changeCount(){
    if(_count<_interval){
        _count++;
    }
    else{
        _count=0;
    }
}

void Tower::erase_Bullet(int x, int y){
    vector<Bullet*>::iterator it;

    it=this->_bullets.begin();

    while (it!=this->_bullets.end()) {
        int flag1=((*it)->getPosX()==x && (*it)->getPosY()==y);

        if(flag1){
            delete (*it);
            it=this->_bullets.erase(it);
            break;
        }
        else{
            it++;
        }
    }
}

void Tower::attack(int direction){
    int m=this->_bullets.size();

    //如果可以发射下一枚子弹，则增加一枚子弹
    if(this->getCount()==this->getInterval() && direction!=0){
        this->_bullets.push_back(new Bullet);
        *(this->_bullets[m])=Bullet::findBullet(this->getBulletType());
        this->_bullets[m]->initObj(this->getBulletType());
        this->_bullets[m]->setPosX(this->getPosX());
        this->_bullets[m]->setPosY(this->getPosY());
    }
    this->changeCount();

    //在范围内的子弹移动，超出范围的子弹销毁
    for(int j=0; j<m; j++){
        if(this->_bullets[j]->getStep()>=this->getArea()){
            this->erase_Bullet(this->_bullets[j]->getPosX(),this->_bullets[j]->getPosY());
        }
        else{
            for(int i=0; i<_bullets[j]->getV(); i++){
                if(_bullets[j]->getDirection()==0){
                    _bullets[j]->setDirection(direction);
                }
                _bullets[j]->move();
            }
        }

    }

}

int Tower::getCost(string type){
    return findtower(type)._cost;
}
