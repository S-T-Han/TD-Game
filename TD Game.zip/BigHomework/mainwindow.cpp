﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->main_menu->setVisible(false);
    ui->return_2->setVisible(false);
    ui->towers_list->setVisible(false);
    ui->score_shower->setVisible(false);
    ui->Tool_list->setVisible(false);
    ui->useless_botton->setVisible(false);
    ui->label->setVisible(false);



    _click_game=false;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_push_to_start_clicked()
{
    move_timer = new QTimer(this);
    connect(move_timer,SIGNAL(timeout()),this,SLOT(Move()));
    move_timer->stop();

    enemies_timer=new QTimer(this);
    connect(enemies_timer,SIGNAL(timeout()),this,SLOT(Add_Enemy()));
    enemies_timer->stop();

    attack_timer=new QTimer(this);
    connect(attack_timer,SIGNAL(timeout()),this,SLOT(Attack()));
    enemies_timer->stop();

    judge_timer=new QTimer(this);
    connect(judge_timer,SIGNAL(timeout()),this,SLOT(Judge()));
    judge_timer->stop();

    end_timer=new QTimer(this);
    connect(end_timer,SIGNAL(timeout()),this,SLOT(Win()));
    end_timer->stop();

    _click_game=false;
    _times=0;

    ui->main_menu->show();
}


void MainWindow::on_game1_clicked()
{

    _click_game=true;

    move_timer->start(500);
    move_timer->setInterval(500);

    enemies_timer->start(750);
    enemies_timer->setInterval(1000);

    attack_timer->start(50);
    attack_timer->setInterval(50);

    judge_timer->start(75);
    judge_timer->setInterval(50);

    end_timer->start(27000);

    _game.initRoad("://game1_road.txt");//载入游戏地图 （TODO 应该是输入有效的地图文件）
    _enemyfile="://game1_enemy.txt";

    ui->return_2->show();
}

void MainWindow::on_game2_clicked()
{
    _click_game=true;

    move_timer->start(500);
    move_timer->setInterval(500);

    enemies_timer->start(750);
    enemies_timer->setInterval(1000);

    attack_timer->start(50);
    attack_timer->setInterval(50);

    judge_timer->start(75);
    judge_timer->setInterval(50);

    end_timer->start(35000);

    _game.initRoad("://game2_road.txt");//载入游戏地图 （TODO 应该是输入有效的地图文件）
    _enemyfile="://game2_enemy.txt";

    ui->return_2->show();
}

void MainWindow::paintEvent(QPaintEvent *e){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->_game.show(pa);
    pa->end();
    delete pa;
}

void MainWindow::mousePressEvent(QMouseEvent *event){
    if(_click_game){
        if(event->button()==Qt::LeftButton && _game.can_build(event->x()/32, event->y()/32)){
            ui->towers_list->setGeometry(QRect((1+event->x()/32)*32, (-1+event->y()/32)*32, 141, 131));
            ui->useless_botton->setGeometry(QRect((event->x()/32)*32, (event->y()/32)*32, 32, 32));
            ui->towers_list->show();
            ui->useless_botton->show();
            _x=event->x()/32;
            _y=event->y()/32;
        }

        else if(event->button()==Qt::LeftButton && _game.have_tower(event->x()/32, event->y()/32).compare("none")){
            ui->Tool_list->setGeometry(QRect((1+event->x()/32)*32, (-1+event->y()/32)*32, 141, 131));
            ui->Tool_list->show();
            _x=event->x()/32;
            _y=event->y()/32;
        }

        else if(event->button()==Qt::RightButton){
            ui->towers_list->hide();
            ui->useless_botton->hide();
        }
    }
}

void MainWindow::Move(){
    this->_game.handle_Enemy_move();
    this->repaint();
}

void MainWindow::Add_Enemy(){
    string type;
    QFile file(_enemyfile);
    QTextStream in(&file);
    QString line;

    if(file.open(QIODevice::ReadOnly | QIODevice::Text)) // 有该文件
    {
        if(!in.atEnd()){
            _times++;
            for(int i=0; i<_times; i++){
                line=in.readLine();
            }
            type=line.toStdString();
            this->_game.handle_Enemy_add(type);
        }
    }
    else // 没有该文件
    {
        cout <<"no such file" << endl;
    }


    this->repaint();
}

void MainWindow::Attack(){
    this->_game.handle_tower_attack();
    this->repaint();
}

void MainWindow::Judge(){
    this->_game.hit_judge();
    this->_game.cross_judge();
    this->repaint();

    ui->score_shower->setValue(_game.getScore());

    if(_game.getLive()<=0){
        move_timer->stop();
        enemies_timer->stop();
        attack_timer->stop();
        judge_timer->stop();
        end_timer->stop();

        ui->label->setText("You Lose");
        ui->label->show();
    }
}


void MainWindow::Win(){
    move_timer->stop();
    enemies_timer->stop();
    attack_timer->stop();
    judge_timer->stop();
    end_timer->stop();

    ui->label->setText("You Win");
    ui->label->show();
}

void MainWindow::on_flame_gun_clicked()
{
     _game.handle_tower_add("flame_gun", _x, _y);
     ui->towers_list->hide();
     ui->useless_botton->hide();
}

void MainWindow::on_mechine_gun_clicked()
{
     _game.handle_tower_add("mechine_gun", _x, _y);
     ui->towers_list->hide();
     ui->useless_botton->hide();
}

void MainWindow::on_canon_clicked()
{
    _game.handle_tower_add("canon", _x, _y);
    ui->towers_list->hide();
    ui->useless_botton->hide();
}

void MainWindow::on_remove_tower_clicked()
{
    _game.erase_Tower(_x, _y);
    ui->Tool_list->hide();
}

void MainWindow::on_return_2_clicked()
{
    _game.cleanWorld();
    _click_game=false;

    delete enemies_timer;
    delete move_timer;
    delete judge_timer;
    delete attack_timer;
    delete end_timer;

    ui->label->hide();
    ui->useless_botton->hide();
    ui->towers_list->hide();
    ui->Tool_list->hide();

    this->repaint();
}

void MainWindow::on_update_tower_clicked()
{
    _game.handle_tower_update(_game.have_tower(_x, _y), _x, _y);

    ui->Tool_list->hide();
}





