#include "mainwindow.h"


#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //init game world
    _game.initWorld("");//TODO 应该是输入有效的地图文件
    _game.initEnemy("fieldstick");

    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(Move()));
        //randomMove()为自定义槽函数
    timer->start(50);
    timer->setInterval(500);

    click=false;
    _number=0;
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    click=true;
}

void MainWindow::paintEvent(QPaintEvent *e){
    if(click){
        QPainter *pa;
        pa = new QPainter();
        pa->begin(this);
        this->_game.show(pa);
        pa->end();
        delete pa;
    }
}

void MainWindow::Move(){
    this->_game.handle_Enemy_move("");
    this->repaint();
}


