#include "tdgobj.h"
#include <iostream>

void TDGObj::initObj(string type)
{
    //TODO 所支持的对象类型应定义为枚举
    if(type.compare("road")==0){
        this->_walkable=true;
        this->_buildable=false;
    }
    else if(type.compare("stone")==0){
        this->_walkable=false;
        this->_buildable=true;
    }
    else if(type.compare("fieldstick")==0){
        this->_walkable=false;
        this->_buildable=false;
    }
    else{
        //TODO 应由专门的错误日志文件记录
        cout<<"invalid ICON type."<<endl;
        return;
    }

    this->_icon = ICON::findICON(type);
    QImage all;

    all.load("://TileB.png");
    this->_pic = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
}

void TDGObj::show(QPainter * pa){
    int gSize = ICON::GRID_SIZE;
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_pic);
}

int TDGObj::getNextX(int direction){
    switch (direction){
        case 1:
            return this->_pos_x;
        case 2:
           return this->_pos_x;
        case 3:
           return this->_pos_x-1;
        case 4:
           return this->_pos_x+1;
    }
}

