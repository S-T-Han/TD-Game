#include "bullet.h"
#include<iostream>

using namespace std;

pair<string, Bullet> PairArray_Bullet[]={
    make_pair("mechine_gun_bullet", Bullet("mechine_gun_bullet", 1, 3)),
    make_pair("flame_gun_bullet", Bullet("flame_gun_bullet", 1, 1)),
    make_pair("canon_bullet", Bullet("canon_bullet", 1, 15)),
    make_pair("update_canon_bullet", Bullet("upate_canon_bullet", 1, 25))
};

map<string, Bullet> Bullet::BULLET_SET(PairArray_Bullet,PairArray_Bullet+sizeof(PairArray_Bullet)/sizeof(PairArray_Bullet[0]));

Bullet::Bullet(string type, int v, int damage):_type(type), _v(v), _damage(damage), _steps(0), _direction(0){}

Bullet Bullet::findBullet(string type){
    map<string, Bullet>::iterator kv;
    kv=Bullet::BULLET_SET.find(type);

    if(kv==Bullet::BULLET_SET.end()){
        cout<<"Error: cannot find enemy"<<endl;
        return Bullet();
    }
    else{
        return kv->second;
    }
}

//子弹只能走直线，方向为上/下/左/右
void Bullet::move(){
    switch (_direction) {
    case 1:
        _pos_x++;
        break;
    case 2:
        _pos_y--;
        break;
    case 3:
        _pos_x--;
        break;
    case 4:
        _pos_y++;
        break;
    case 0:
        break;
    }

    _steps++;
}
