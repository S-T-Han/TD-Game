#ifndef ENEMY_H
#define ENEMY_H
#include"tdgobj.h"
#include <string>
#include<map>

using namespace std;

class Enemy : public TDGObj
{
public:
    static map<string, Enemy> ENEMY_SET;
    static Enemy findenemy(string type);

    Enemy(){};
    Enemy(string type, int v, int blood);

    void move(){this->_pos_x++;}
protected:
    string _type;
    int _v, _blood;
};

#endif // ENEMY_H
