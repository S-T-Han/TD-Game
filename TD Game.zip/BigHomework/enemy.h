#ifndef ENEMY_H
#define ENEMY_H
#include"tdgobj.h"
#include <string>
#include<map>

using namespace std;

class Enemy : public TDGObj
{
public:
    static map<string, Enemy> ENEMY_SET;//确定各类敌人的属性
    static Enemy findenemy(string type);//通过名称找到敌人，读取对应的数据

    Enemy(){_steps=0;}
    Enemy(string type, int v, int blood);

    void move(int direction);//敌人向某个方向移动
    void get_hit(int damage){_blood-=damage;}//敌人扣血

    string getEnemyType() const{return _type;}
    int getBlood() const {return _blood;}
    int getSteps() const {return _steps;}
    int getV() const {return _v;}


protected:
    string _type;//敌人的名称
    int _v, _blood, _steps;//敌人的速度，血量，已经走过的步数
    //速度为敌人每一次移动调用move的次数
};

#endif // ENEMY_H
