#include "icon.h"
#include<iostream>
int ICON::GRID_SIZE = 32;


pair<string,ICON> pairArray[] =
{
    make_pair("fieldstick", ICON("fieldstick", 1, 14, 1, 1)),
    make_pair("mechine_gun_bullet", ICON("mechine_gun_bullet", 4, 9, 1, 1)),
    make_pair("flame_gun_bullet", ICON("flame_gun_bullet", 8, 11, 1, 1)),
    make_pair("road", ICON("road", 5, 1, 1, 1)),
    make_pair("mechine_gun", ICON("mechine_gun", 6, 9, 1, 1)),
    make_pair("flame_gun", ICON("flame_gun", 8, 10, 1, 1)),
    make_pair("heart", ICON("heart", 10, 13, 1, 1)),
    make_pair("bug", ICON("bug", 1, 4, 1, 1)),
    make_pair("overload", ICON("overload", 1, 1, 1, 1)),
    make_pair("empty", ICON("empty", 0, 0, 1, 1)),
    make_pair("update_mechine_gun", ICON("update_mechine_gun", 7, 9, 1, 1)),
    make_pair("update_flame_gun", ICON("update_flame_gun", 9, 10, 1, 1)),
    make_pair("canon", ICON("canon", 2, 5, 1, 1)),
    make_pair("canon_bullet", ICON("canon_bullet", 3, 7, 1, 1)),
    make_pair("update_canon_bullet", ICON("update_canon_bullet", 5, 14, 1, 1)),
    make_pair("update_canon", ICON("update_canon", 4, 5, 1, 1))
};

map<string,ICON> ICON::GAME_ICON_SET(pairArray,pairArray+sizeof(pairArray)/sizeof(pairArray[0]));


ICON::ICON(string name, int x, int y, int w, int h){
    this->typeName = name;
    this->srcX = x;
    this->srcY = y;
    this->width = w;
    this->height = h;
}

ICON ICON::findICON(string type){
    map<string,ICON>::iterator kv;
    kv = ICON::GAME_ICON_SET.find(type);

    if (kv==ICON::GAME_ICON_SET.end()){
       cout<<"Error: cannot find ICON"<<endl;
       return ICON();
    }
    else{
        return kv->second;
    }
}

